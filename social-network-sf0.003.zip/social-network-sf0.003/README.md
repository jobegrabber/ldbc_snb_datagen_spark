Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/36d6628e7717339f8d6720c7080cf008d6139d97>
