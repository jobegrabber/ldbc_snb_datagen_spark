Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/a2ffaed80dcc38307d4ffb88cf020ba927be4f8a>
