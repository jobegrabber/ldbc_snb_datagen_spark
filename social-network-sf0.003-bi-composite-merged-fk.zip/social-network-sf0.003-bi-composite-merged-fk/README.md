Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/58a363806c1dfe0bcb3b8c99b98e95b0d75999a8>
