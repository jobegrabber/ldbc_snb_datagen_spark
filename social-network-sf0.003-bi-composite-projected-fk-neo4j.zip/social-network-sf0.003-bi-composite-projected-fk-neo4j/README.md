Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/94eec9e7f5630bb6c1d457bf742848af61065454>
