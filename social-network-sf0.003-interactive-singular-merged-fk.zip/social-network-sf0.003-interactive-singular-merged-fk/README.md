Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/dc5211e82b0f6b10111650d500fc32988ea68928>
