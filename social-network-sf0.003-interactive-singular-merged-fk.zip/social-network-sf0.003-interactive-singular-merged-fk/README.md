Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/3477d0f175c6fdc10a378c69683c74308f02cf7b>
