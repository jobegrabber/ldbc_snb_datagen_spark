Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/c71780f8c8f1fae7e8cede718db3e6b3c582bfd7>
