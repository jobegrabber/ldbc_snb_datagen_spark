Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/3e46ef8e7ca615f28328c84eff9bb242695ab7b7>
