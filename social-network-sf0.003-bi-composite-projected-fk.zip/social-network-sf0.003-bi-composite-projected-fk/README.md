Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/26f22f2dc0042f89b4eec6bb7d9caaafc8ae31cc>
